﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LOGIN_BD_SAMUEL_BLANCO
{
    // La clase Form1 representa una ventana de formulario en una aplicación de Windows Forms
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Evento que se ejecuta cuando se carga el formulario
        private void Form1_Load(object sender, EventArgs e)
        {
            // Código para ejecutar cuando se carga el formulario
        }

        // Evento que se ejecuta cuando se hace clic en el botón "BtnIniciar"
        private void BtnIniciar_Click(object sender, EventArgs e)
        {
            // Crear una instancia de la clase Usuarios
            Usuarios Usuarioo = new Usuarios();

            // Asignar los valores de los campos de texto a las propiedades de la instancia de Usuarios
            Usuarioo.Usuario = this.TxtUsuario.Text;
            Usuarioo.Contraseña = this.TxtContraseña.Text;

            // Verificar si el usuario existe en la base de datos
            if (Usuarioo.Buscar() == true)
            {
                MessageBox.Show(Usuarioo.Mensaje, "Login");
            }
            else
            {
                MessageBox.Show(Usuarioo.Mensaje, "ERROR");
            }

            // Limpiar los campos de texto
            TxtUsuario.Clear();
            TxtContraseña.Clear();
        }
    }
}
