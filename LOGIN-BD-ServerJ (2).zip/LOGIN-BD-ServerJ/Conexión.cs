﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace LOGIN_BD_SAMUEL_BLANCO
{
    // La clase Conexión se utiliza para establecer una conexión con una base de datos
    class Conexión
    {
        public string cadenaConexion;
        protected string sql;
        protected string resultado;
        protected SqlConnection conn;
        protected SqlCommand comandosql;
        protected string mensaje;

        // Constructor de la clase Conexión
        public Conexión()
        {
            // Establecer la cadena de conexión a la base de datos
            this.cadenaConexion = ("server=LAPTOP-59CUCAF2;database=USUARIOSPRUEBA; integrated security=true");
            this.conn = new SqlConnection(this.cadenaConexion);
        }

        // Propiedad de solo lectura para obtener el mensaje de la conexión
        public string Mensaje
        {
            get { return this.mensaje; }
        }
    }
}

