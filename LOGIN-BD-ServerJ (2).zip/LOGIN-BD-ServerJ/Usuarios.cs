﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace LOGIN_BD_SAMUEL_BLANCO
{
    // La clase Usuarios hereda de la clase Conexión
    class Usuarios : Conexión
    {
        private string usuario;
        private string contraseña;

        // Constructor de la clase Usuarios
        public Usuarios()
        {
            usuario = string.Empty;
            contraseña = string.Empty;
            this.sql = string.Empty;
        }

        // Propiedad para la variable usuario
        public string Usuario
        {
            get { return usuario; }
            set { this.usuario = value; }
        }

        // Propiedad para la variable contraseña
        public string Contraseña
        {
            get { return contraseña; }
            set { contraseña = value; }
        }

        // Método para buscar un usuario en la base de datos
        public bool Buscar()
        {
            bool Resultado = false;
            // Construir la consulta SQL utilizando las variables usuario y contraseña
            this.sql = string.Format("SELECT * FROM Usuarios WHERE Usuario='{0}' AND Contraseña='{1}'", this.usuario, this.contraseña);
            this.comandosql = new SqlCommand(this.sql, this.conn);
            this.conn.Open();
            SqlDataReader Reg = null;
            Reg = this.comandosql.ExecuteReader();
            if (Reg.Read())
            {
                Resultado = true;
                this.mensaje = "Bienvenido, Datos Correctos";
            }
            else
            {
                this.mensaje = "Datos Incorrectos, verifique por favor";
            }
            this.conn.Close();
            return Resultado;
        }
    }
}

